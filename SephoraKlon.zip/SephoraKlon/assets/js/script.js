// Mega menu touch/click support
(function(){
  const navItems = document.querySelectorAll('.main-nav .nav-item');
  navItems.forEach(item => {
    const link = item.querySelector('a');
    const panel = item.querySelector('.mega-menu');
    if(!panel) return;

    let open = false;
    const openMenu = () => { item.classList.add('open'); item.querySelector('.mega-menu')?.setAttribute('aria-hidden','false'); open = true; };
    const closeMenu = () => { item.classList.remove('open'); item.querySelector('.mega-menu')?.setAttribute('aria-hidden','true'); open = false; };

    // First tap opens, second tap follows link
    link.addEventListener('click', (e) => {
      if(window.matchMedia('(max-width: 900px)').matches){
        if(!open){ e.preventDefault(); openMenu(); }
      }
    });

    // Close on outside click
    document.addEventListener('click', (e) => {
      if(!item.contains(e.target)) closeMenu();
    });

    // Close on ESC
    document.addEventListener('keydown', (e) => {
      if(e.key === 'Escape') closeMenu();
    });
  });
})();
// Basit JS: slider, form ve buton etkileşimleri
document.addEventListener('DOMContentLoaded', function(){
  let allProducts = [];
  async function loadProducts(){
    try {
      const response = await fetch('assets/data/products.json');
      allProducts = await response.json();
    } catch(e) {
      console.error('Ürünler yüklenemedi:', e);
    }
  }
  loadProducts();

  // Slider
  const slides = document.querySelectorAll('.slider .slide');
  let idx = 0;
  function showSlide(i){
    slides.forEach(s=>s.classList.remove('active'));
    slides[i].classList.add('active');
  }
  if(slides.length>0){
    showSlide(0);
    setInterval(()=>{
      idx = (idx+1)%slides.length;
      showSlide(idx);
    },4000);
  }

  // Arama Fonksiyonalitesi
  const searchInput = document.querySelector('.search-wrap input');
  const searchBtns = document.querySelectorAll('.search-btn');
  function performSearch(){
    const query = searchInput.value.toLowerCase().trim();
    if(!query){
      alert('Arama yapmak için ürün adı veya marka yazın');
      return;
    }
    const results = allProducts.filter(p=>p.name.toLowerCase().includes(query) || p.brand.toLowerCase().includes(query));
    if(results.length === 0){
      alert('Arama sonucu: "' + query + '" için ürün bulunamadı.');
      return;
    }
    sessionStorage.setItem('searchResults', JSON.stringify(results));
    window.location.href = 'urunler.html?search=' + encodeURIComponent(query);
  }
  searchBtns.forEach(btn=>btn.addEventListener('click', performSearch));
  if(searchInput) searchInput.addEventListener('keypress', (e)=>{ if(e.key === 'Enter') performSearch(); });

  // Sepete ekle butonu
  const addBtn = document.getElementById('addToCart');
  if(addBtn){
    addBtn.addEventListener('click', ()=>{
      alert('Sepete eklendi');
    });
  }

  // Contact form
  const contactForm = document.getElementById('contactForm');
  if(contactForm){
    contactForm.addEventListener('submit', function(e){
      e.preventDefault();
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const message = document.getElementById('message').value.trim();
      if(!name||!email||!message){
        alert('Lütfen tüm alanları doldurun');
        return;
      }
      alert('Form gönderildi');
      contactForm.reset();
    });
  }
});
