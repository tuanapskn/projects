// Basit sepet yönetimi (localStorage)
(function(){
  const STORAGE_KEY = 'sephora_cart';

  function getCart(){
    try{
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    }catch(e){
      return [];
    }
  }

  function saveCart(cart){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
    updateCartCount();
  }

  function updateCartCount(){
    const cart = getCart();
    const count = cart.reduce((s,i)=>s+i.qty,0);
    const el = document.getElementById('cartCount');
    if(el) {
      if(count === 0) {
        el.textContent = '';
      } else {
        el.textContent = count;
      }
    }
  }

  function addToCart(item){
    const cart = getCart();
    const found = cart.find(i=>i.id===item.id);
    if(found){
      found.qty += item.qty;
    }else{
      cart.push(item);
    }
    saveCart(cart);
  }

  function renderCartPage(){
    const root = document.getElementById('cartRoot');
    const empty = document.getElementById('cartEmpty');
    if(!root) return;
    const cart = getCart();
    root.innerHTML = '';
    if(cart.length===0){
      if(empty) empty.style.display = 'block';
      return;
    }
    if(empty) empty.style.display = 'none';

    const list = document.createElement('div');
    list.className = 'cart-list';

    let total = 0;
    cart.forEach(item=>{
      const row = document.createElement('div');
      row.className = 'cart-row';
      row.innerHTML = `
        <img src="${item.image}" alt="${item.name}" style="width:80px;height:80px;object-fit:contain;margin-right:12px;border:1px solid #eee;padding:6px;border-radius:6px">
        <div style="flex:1">
          <div style="font-weight:700">${item.name}</div>
          <div style="color:var(--muted)">₺${item.price} x ${item.qty}</div>
        </div>
        <div style="min-width:120px;text-align:right">₺${(item.price*item.qty).toFixed(2)}</div>
      `;
      row.style.display = 'flex';
      row.style.alignItems = 'center';
      row.style.gap = '12px';
      row.style.padding = '12px 0';
      list.appendChild(row);
      total += item.price*item.qty;
    });

    const summary = document.createElement('div');
    summary.style.marginTop = '18px';
    summary.innerHTML = `<div style="text-align:right;font-weight:700;font-size:18px">Toplam: ₺${total.toFixed(2)}</div>
      <div style="text-align:right;margin-top:12px"><a href="index.html" class="btn primary">Alışverişe Devam Et</a> <button id="checkoutBtn" class="btn">Siparişi Tamamla (Demo)</button></div>`;

    root.appendChild(list);
    root.appendChild(summary);

    const checkoutBtn = document.getElementById('checkoutBtn');
    if(checkoutBtn){
      checkoutBtn.addEventListener('click', ()=>{
        alert('Demo: ödeme sayfası yok. Sepeti temizleyeceğim.');
        localStorage.removeItem(STORAGE_KEY);
        renderCartPage();
      });
    }
  }

  // Dinamik olarak sayfalara event bağlama
  document.addEventListener('DOMContentLoaded', function(){
    // Sepet sayfası render
    renderCartPage();
    updateCartCount();

    // Tüm 'Sepete Ekle' butonları
    document.querySelectorAll('.add-to-cart').forEach(btn=>{
      btn.addEventListener('click', function(){
        const id = this.getAttribute('data-id');
        const name = this.getAttribute('data-name');
        const price = parseFloat(this.getAttribute('data-price'))||0;
        const image = this.getAttribute('data-image')||'';
        addToCart({id: String(id), name, price, image, qty:1});
        alert(name + ' sepete eklendi');
      });
    });

    // Detail sayfasındaki buton (id addToCart)
    const addBtn = document.getElementById('addToCart');
    if(addBtn){
      addBtn.addEventListener('click', function(){
        const id = this.getAttribute('data-id') || 'detail';
        const name = this.getAttribute('data-name') || document.querySelector('.detail-info h1')?.textContent||'Ürün';
        const price = parseFloat(this.getAttribute('data-price'))|| parseFloat(document.querySelector('.detail-info .price')?.textContent.replace(/[^0-9.,]/g,'')) || 0;
        const image = this.getAttribute('data-image') || document.querySelector('.detail-media img')?.getAttribute('src')||'';
        addToCart({id: String(id), name, price, image, qty:1});
        alert(name + ' sepete eklendi');
      });
    }
  });

  // expose for other scripts if needed
  window.sephoraCart = {getCart, addToCart, updateCartCount};
})();

// Wishlist (İstek Listesi) yönetimi
(function(){
  const WISHLIST_KEY = 'sephora_wishlist';
  
  function getWishlist(){
    try{
      return JSON.parse(localStorage.getItem(WISHLIST_KEY)) || [];
    }catch(e){
      return [];
    }
  }
  
  function saveWishlist(list){
    localStorage.setItem(WISHLIST_KEY, JSON.stringify(list));
    updateWishlistCount();
  }
  
  function updateWishlistCount(){
    const wishlist = getWishlist();
    const els = document.querySelectorAll('.wishlist-count');
    els.forEach(el=>el.textContent = wishlist.length);
  }
  
  function toggleWishlist(item){
    const wishlist = getWishlist();
    const idx = wishlist.findIndex(i=>i.id === item.id);
    if(idx >= 0){
      wishlist.splice(idx, 1);
    }else{
      wishlist.push(item);
    }
    saveWishlist(wishlist);
    return idx < 0; // true if added
  }
  
  function isInWishlist(id){
    return getWishlist().some(i=>i.id === id);
  }
  
  document.addEventListener('DOMContentLoaded', function(){
    updateWishlistCount();
    
    // İstek listesi butonları
    document.querySelectorAll('.wishlist-btn, .heart-icon').forEach(btn=>{
      const id = btn.getAttribute('data-id');
      if(id && isInWishlist(id)){
        btn.classList.add('active');
        btn.innerHTML = '❤️';
      } else {
        btn.innerHTML = '♡';
      }
      
      btn.addEventListener('click', function(e){
        e.preventDefault();
        const pid = this.getAttribute('data-id');
        const pname = this.getAttribute('data-name') || 'Ürün';
        const pprice = parseFloat(this.getAttribute('data-price')) || 0;
        const pimage = this.getAttribute('data-image') || '';
        const pbrand = this.getAttribute('data-brand') || '';
        
        const added = toggleWishlist({id: pid, name: pname, price: pprice, image: pimage, brand: pbrand});
        
        if(added){
          this.classList.add('active');
          this.innerHTML = '❤️';
          alert(pname + ' istek listesine eklendi');
        } else {
          this.classList.remove('active');
          this.innerHTML = '♡';
          alert(pname + ' istek listesinden çıkarıldı');
        }
      });
    });
  });
  
  window.sephoraWishlist = {getWishlist, toggleWishlist, isInWishlist};
})();
