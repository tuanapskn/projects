// Mega dropdown menü işlevselliği
document.addEventListener('DOMContentLoaded', function() {
  const navItems = document.querySelectorAll('.nav-item');
  const header = document.querySelector('.site-header');
  
  // Header yüksekliğini hesapla ve dropdown'lara uygula
  function updateDropdownPosition() {
    const headerHeight = header ? header.offsetHeight : 140;
    document.querySelectorAll('.mega-dropdown').forEach(dropdown => {
      dropdown.style.top = headerHeight + 'px';
    });
  }
  
  // Sayfa yüklendiğinde ve pencere boyutu değiştiğinde güncelle
  updateDropdownPosition();
  window.addEventListener('resize', updateDropdownPosition);
  
  navItems.forEach(item => {
    const dropdown = item.querySelector('.mega-dropdown');
    if (!dropdown) return;
    
    // Hover açılma
    item.addEventListener('mouseenter', function() {
      updateDropdownPosition(); // Her açılışta güncelle
      dropdown.style.display = 'flex';
      dropdown.style.visibility = 'visible';
      dropdown.style.opacity = '1';
    });
    
    item.addEventListener('mouseleave', function() {
      dropdown.style.display = 'none';
      dropdown.style.visibility = 'hidden';
      dropdown.style.opacity = '0';
    });
  });
  
  // Mobile uyumluluğu
  if (window.matchMedia('(max-width: 900px)').matches) {
    navItems.forEach(item => {
      const link = item.querySelector('a');
      if (link && item.querySelector('.mega-dropdown')) {
        link.addEventListener('click', function(e) {
          e.preventDefault();
        });
      }
    });
  }
});
