document.addEventListener('DOMContentLoaded', function(){
  const grid = document.getElementById('productGrid');
  if(!grid) return;
  
  let allProducts = [];
  let displayedProducts = [];
  
  async function loadAndRenderProducts(){
    try {
      const response = await fetch('assets/data/products.json');
      allProducts = await response.json();
      
      // URL'den kategori kontrolü yap
      const urlParams = new URLSearchParams(window.location.search);
      const category = document.body.getAttribute('data-category');
      const searchQuery = urlParams.get('search');
      
      let filtered = allProducts;
      
      // Kategori filtrelemesi
      if(category && category !== 'all'){
        filtered = filtered.filter(p=>p.category === category);
      }
      
      // Arama filtrelemesi
      if(searchQuery){
        filtered = filtered.filter(p=>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.brand.toLowerCase().includes(searchQuery.toLowerCase())
        );
      }
      
      renderProducts(filtered);
    } catch(e) {
      console.error('Ürünler yüklenemedi:', e);
    }
  }
  
  function renderProducts(productsToRender){
    grid.innerHTML = '';
    productsToRender.forEach(p=>{
      const card = document.createElement('article');
      card.className = 'product-card';
      card.setAttribute('data-id', p.id);
      card.setAttribute('data-brand', p.brand);
      card.setAttribute('data-price', p.price);
      card.setAttribute('data-color', p.color);
      card.innerHTML = `
        <img src="${p.image}" alt="${p.name}">
        <h3>${p.name}</h3>
        <p class="brand">${p.brand}</p>
        <p class="price">₺${p.price}${p.discount > 0 ? ' <span style="text-decoration:line-through">₺'+(p.price/(1-p.discount/100)).toFixed(0)+'</span>' : ''}</p>
        ${p.discount > 0 ? '<p style="color:#d62e6b;font-weight:700">-%' + p.discount + '</p>' : ''}
        <p style="font-size:12px;color:#888">${p.rating}⭐ (${p.reviews} yorum)</p>
        <div class="card-actions">
          <button class="wishlist-btn heart-icon" data-id="${p.id}" data-name="${p.name}" data-price="${p.price}" data-image="${p.image}" data-brand="${p.brand}" title="İstek Listesine Ekle">♡</button>
          <a href="urun-detay.html?id=${p.id}" class="btn">İncele</a>
          <button class="add-to-cart btn primary" data-id="${p.id}" data-name="${p.name}" data-price="${p.price}" data-image="${p.image}">Sepete Ekle</button>
        </div>
      `;
      grid.appendChild(card);
    });
    displayedProducts = Array.from(grid.querySelectorAll('.product-card'));
  }
  
  const products = Array.from(grid.querySelectorAll('.product-card'));

  const brandInputs = Array.from(document.querySelectorAll('input[name="brand"]'));
  const colorInputs = Array.from(document.querySelectorAll('input[name="color"]'));
  const priceMin = document.getElementById('priceMin');
  const priceMax = document.getElementById('priceMax');
  const rangeMin = document.getElementById('rangeMin');
  const rangeMax = document.getElementById('rangeMax');
  const rangeFill = document.getElementById('rangeFill');
  const rangeMinVal = document.getElementById('rangeMinVal');
  const rangeMaxVal = document.getElementById('rangeMaxVal');
  const sortSelect = document.getElementById('sortBy');
  const clearBtn = document.getElementById('clearFilters');
  const countEl = document.getElementById('resultCount');
  const brandSearch = document.getElementById('brandSearch');

  function applyFilters(){
    const selectedBrands = brandInputs.filter(i=>i.checked).map(i=>i.value);
    const selectedColors = colorInputs.filter(i=>i.checked).map(i=>i.value);
    const min = parseFloat(priceMin.value) || 0;
    const max = parseFloat(priceMax.value) || Infinity;

    let visible = 0;
    products.forEach(p=>{
      const brand = p.dataset.brand;
      const price = parseFloat(p.dataset.price) || 0;
      const colors = (p.dataset.color||'').split(',').map(s=>s.trim()).filter(Boolean);

      let ok = true;
      if(selectedBrands.length && !selectedBrands.includes(brand)) ok = false;
      if(selectedColors.length && !colors.some(c=>selectedColors.includes(c))) ok = false;
      if(price < min || price > max) ok = false;

      p.style.display = ok ? '' : 'none';
      if(ok) visible++;
    });
    countEl.textContent = visible;
    applySort();
  }

  // Collapsible filter headers
  document.querySelectorAll('.filter-block h4').forEach(h=>{
    h.addEventListener('click', ()=>{
      const parent = h.closest('.filter-block');
      if(parent.classList.contains('collapsible')){
        parent.classList.toggle('open');
        const caret = parent.querySelector('.caret');
        if(caret) caret.textContent = parent.classList.contains('open') ? '▾' : '▸';
      }
    });
  });

  // Range slider sync: keep number inputs and range inputs in sync and update fill
  function updateRangeFill(){
    if(!rangeMin || !rangeMax || !rangeFill) return;
    const min = parseInt(rangeMin.min||0,10);
    const max = parseInt(rangeMax.max||3000,10);
    let v1 = Math.min(parseInt(rangeMin.value,10), parseInt(rangeMax.value,10));
    let v2 = Math.max(parseInt(rangeMin.value,10), parseInt(rangeMax.value,10));
    const left = ((v1 - min)/(max-min))*100;
    const right = 100-((v2 - min)/(max-min))*100;
    rangeFill.style.left = left+'%';
    rangeFill.style.right = right+'%';
    if(rangeMinVal) rangeMinVal.textContent = v1;
    if(rangeMaxVal) rangeMaxVal.textContent = v2;
    if(priceMin) priceMin.value = v1;
    if(priceMax) priceMax.value = v2;
  }

  if(rangeMin && rangeMax){
    rangeMin.addEventListener('input', ()=>{ updateRangeFill(); applyFilters(); });
    rangeMax.addEventListener('input', ()=>{ updateRangeFill(); applyFilters(); });
    // initialize
    updateRangeFill();
  }
  // sync number inputs to ranges
  if(priceMin) priceMin.addEventListener('input', ()=>{ if(rangeMin) rangeMin.value = priceMin.value; updateRangeFill(); applyFilters(); });
  if(priceMax) priceMax.addEventListener('input', ()=>{ if(rangeMax) rangeMax.value = priceMax.value; updateRangeFill(); applyFilters(); });

  function applySort(){
    const val = sortSelect.value;
    // take only visible products
    const visibleProducts = products.filter(p=>p.style.display !== 'none');
    let sorted = visibleProducts.slice();
    if(val === 'price-asc') sorted.sort((a,b)=>parseFloat(a.dataset.price)-parseFloat(b.dataset.price));
    else if(val === 'price-desc') sorted.sort((a,b)=>parseFloat(b.dataset.price)-parseFloat(a.dataset.price));
    else if(val === 'name-asc') sorted.sort((a,b)=>a.querySelector('h3').textContent.localeCompare(b.querySelector('h3').textContent));
    else if(val === 'name-desc') sorted.sort((a,b)=>b.querySelector('h3').textContent.localeCompare(a.querySelector('h3').textContent));

    // append in sorted order
    sorted.forEach(p=>grid.appendChild(p));
  }

  // wire events
  brandInputs.forEach(i=>i.addEventListener('change', applyFilters));
  colorInputs.forEach(i=>i.addEventListener('change', applyFilters));
  priceMin && priceMin.addEventListener('input', applyFilters);
  priceMax && priceMax.addEventListener('input', applyFilters);
  sortSelect && sortSelect.addEventListener('change', applySort);
  clearBtn && clearBtn.addEventListener('click', function(){
    brandInputs.forEach(i=>i.checked = false);
    colorInputs.forEach(i=>i.checked = false);
    if(priceMin) priceMin.value = '';
    if(priceMax) priceMax.value = '';
    sortSelect.value = 'default';
    applyFilters();
  });

  brandSearch && brandSearch.addEventListener('input', function(){
    const q = brandSearch.value.trim().toLowerCase();
    const labels = document.querySelectorAll('#brandList label');
    labels.forEach(lbl=>{
      const txt = lbl.textContent.trim().toLowerCase();
      lbl.style.display = txt.includes(q) ? '' : 'none';
    });
  });

  // initial

    // Ürünleri JSON'dan yükle ve render et
    loadAndRenderProducts();
  applyFilters();
});
